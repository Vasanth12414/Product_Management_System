const API_URL = "http://localhost:5001/api/products";

// ✅ Add Product (Show Popup on Success)
document.getElementById("productForm")?.addEventListener("submit", async function (event) {
    event.preventDefault();

    let name = document.getElementById("name").value.trim();
    let price = parseFloat(document.getElementById("price").value.trim()) || 0;
    let quantity = parseInt(document.getElementById("quantity").value.trim()) || 0;
    let brand = document.getElementById("brand").value.trim();
    let netWeight = document.getElementById("netWeight").value.trim();
    let manufacturer = document.getElementById("manufacturer").value.trim();
    let description = document.getElementById("description").value.trim();
    let totalPrice = (price * quantity).toFixed(2); // Calculate total price dynamically

    if (!name || !price || !quantity || !brand || !netWeight || !manufacturer || !description) {
        alert("❌ Please fill in all fields!");
        return;
    }

    let productData = { name, price, quantity, brand, netWeight, manufacturer, totalPrice, description };

    try {
        let response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(productData),
        });

        // Log the full response for debugging
        console.log("🔹 Full Response:", response);

        let result = await response.json();
        console.log("🔹 Add Product Response:", result);

        if (result.success) {
            alert("✅ Product Added Successfully!");
            document.getElementById("productForm").reset();
            fetchProducts(); // Refresh the table after adding
        } else {
            alert("❌ Error adding product: " + result.message);
        }
    } catch (error) {
        console.error("❌ Error adding product:", error);
        alert("❌ Failed to add product! Check console for details.");
    }
});
// ✅ Fetch & Display Products in Table
async function fetchProducts(includeImages = false) {
    try {
        let response = await fetch(API_URL);
        let data = await response.json();

        console.log("🔹 Fetch Products Response:", data);

        let tableContent = `<table>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Brand</th>
                <th>Net Weight</th>
                <th>Manufacturer</th>
                <th>Total Price</th>
                <th>Description</th>
                ${includeImages ? '<th>Image</th>' : ''}
                <th>Actions</th>
            </tr>`;

        if (data.success && Array.isArray(data.products) && data.products.length > 0) {
            data.products.forEach(product => {
                tableContent += `
                    <tr>
                        <td>${product.name}</td>
                        <td>₹${product.price}</td>
                        <td>${product.quantity}</td>
                        <td>${product.brand}</td>
                        <td>${product.netWeight}</td>
                        <td>${product.manufacturer}</td>
                        <td>₹${product.totalPrice}</td>
                        <td>${product.description}</td>
                        ${includeImages ? `<td>${product.image ? `<img src="${product.image}" alt="${product.name}" width="50">` : "No Image"}</td>` : ''}
                        <td>
                            <button class="small-btn edit-btn" onclick="editProduct('${product._id}', '${product.name}', ${product.price}, ${product.quantity}, '${product.brand}', '${product.netWeight}', '${product.manufacturer}', '${product.description}')">✏️ Edit</button>
                            <button class="small-btn delete-btn" onclick="deleteProduct('${product._id}')">🗑️ Delete</button>
                            <button class="small-btn add-btn" onclick="uploadImage('${product._id}')">📷 Add Image</button>
                        </td>
                    </tr>
                `;
            });
        } else {
            tableContent += `<tr><td colspan="10">No products found!</td></tr>`;
        }

        tableContent += `</table>`;
        document.getElementById(includeImages ? "productList" : "products").innerHTML = tableContent;
    } catch (error) {
        console.error("❌ Error fetching products:", error);
        document.getElementById(includeImages ? "productList" : "products").innerHTML = "<p>Error loading products!</p>";
    }
}

// ✅ Upload Product Image
async function uploadImage(productId) {
    let fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = "image/*";

    fileInput.addEventListener("change", async function () {
        let file = fileInput.files[0];
        if (!file) return;

        let formData = new FormData();
        formData.append("image", file);

        try {
            let response = await fetch(`${API_URL}/${productId}/upload`, {
                method: "POST",
                body: formData
            });

            let result = await response.json();
            console.log("🔹 Image Upload Response:", result);

            if (result.success) {
                alert("✅ Image Uploaded Successfully!");
                fetchProducts(true); // Refresh product list with images
            } else {
                alert("❌ Error uploading image!");
            }
        } catch (error) {
            console.error("❌ Error uploading image:", error);
            alert("❌ Failed to upload image!");
        }
    });

    fileInput.click();
}

// ✅ Edit Product
async function editProduct(id, name, price, quantity, brand, netWeight, manufacturer, description) {
    let newName = prompt("Edit Product Name:", name);
    let newPrice = prompt("Edit Product Price:", price);
    let newQuantity = prompt("Edit Product Quantity:", quantity);
    let newBrand = prompt("Edit Product Brand:", brand);
    let newNetWeight = prompt("Edit Product Net Weight:", netWeight);
    let newManufacturer = prompt("Edit Product Manufacturer:", manufacturer);
    let newDescription = prompt("Edit Product Description:", description);

    if (!newName || !newPrice || !newQuantity || !newBrand || !newNetWeight || !newManufacturer || !newDescription) {
        alert("❌ All fields are required!");
        return;
    }

    let updatedProduct = {
        name: newName,
        price: parseFloat(newPrice),
        quantity: parseInt(newQuantity),
        brand: newBrand,
        netWeight: newNetWeight,
        manufacturer: newManufacturer,
        totalPrice: (parseFloat(newPrice) * parseInt(newQuantity)).toFixed(2), // Recalculate total price
        description: newDescription,
    };

    try {
        let response = await fetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(updatedProduct),
        });

        let result = await response.json();
        console.log("🔹 Edit Product Response:", result);

        if (result.success) {
            alert("✅ Product Updated Successfully!");
            fetchProducts(); // Refresh table
        } else {
            alert("❌ Error updating product!");
        }
    } catch (error) {
        console.error("❌ Error updating product:", error);
        alert("❌ Failed to update product!");
    }
}

async function deleteProduct(id) {
    console.log("🔹 Deleting product with ID:", id); // Log the ID
    if (!confirm("Are you sure you want to delete this product?")) return;

    try {
        let response = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
        let result = await response.json();

        console.log("🔹 Delete Product Response:", result);

        if (result.success) {
            alert("🗑️ Product Deleted!");
            fetchProducts(); // Refresh table
        } else {
            alert("❌ Error deleting product!");
        }
    } catch (error) {
        console.error("❌ Error deleting product:", error);
        alert("❌ Failed to delete product!");
    }
}

// ✅ Load Products on Page Load
document.addEventListener("DOMContentLoaded", function () {
    if (document.getElementById("products")) {
        fetchProducts(); // Fetch products without images
    }
    if (document.getElementById("productList")) {
        fetchProducts(true); // Fetch products with images
    }
});

