document.addEventListener("DOMContentLoaded", function () {
    const product = JSON.parse(sessionStorage.getItem("selectedProduct"));

    if (!product) {
        alert("No product details found. Redirecting...");
        window.location.href = "productslist.html";
        return;
    }

    // Display the price of the product
    document.getElementById("price").innerHTML = `<strong>Amount: ₹${product.price}</strong>`;

    // 🔹 YOUR UPI PAYMENT DETAILS (Replace with your UPI ID)
    const upiId = "vasanthreddy15591@oksbi";  // Change this to your UPI ID
    const paymentURL = `upi://pay?pa=${upiId}&pn=YourName&mc=&tid=&tr=&tn=Payment for ${encodeURIComponent(product.name)}&am=${product.price}&cu=INR`;

    // Generate QR Code
    new QRCode(document.getElementById("qrcode"), {
        text: paymentURL,
        width: 200,
        height: 200
    });

    // Reverse Countdown Timer (1:30 min)
    let timeLeft = 90;
    const timerElement = document.getElementById("timer");

    function updateTimer() {
        let minutes = Math.floor(timeLeft / 60);
        let seconds = timeLeft % 60;
        timerElement.textContent = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
        
        if (timeLeft <= 0) {
            clearInterval(countdown);
            alert("Payment time expired!");
            window.location.href = "productslist.html";
        }
        timeLeft--;
    }

    updateTimer();
    const countdown = setInterval(updateTimer, 1000);
});
