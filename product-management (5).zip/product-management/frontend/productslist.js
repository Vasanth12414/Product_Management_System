const API_URL = "http://localhost:5001/api/products";

let allProducts = []; // To store all products fetched from the API

// Fetch and display products in an e-commerce style layout
async function fetchProducts() {
    try {
        let response = await fetch(API_URL);
        let data = await response.json();

        console.log("🔹 Fetch Products Response:", data);

        if (data.success && Array.isArray(data.products) && data.products.length > 0) {
            allProducts = data.products; // Store all products
            displayProducts(allProducts); // Display all products initially
        } else {
            document.getElementById("productList").innerHTML = "<p>No products found!</p>";
        }
    } catch (error) {
        console.error("❌ Error fetching products:", error);
        document.getElementById("productList").innerHTML = "<p>Error loading products!</p>";
    }
}

// Function to display products
function displayProducts(products) {
    let productContainer = document.getElementById("productList");
    productContainer.innerHTML = ""; // Clear previous content

    if (products.length > 0) {
        products.forEach(product => {
            let productCard = document.createElement("div");
            productCard.className = "product-card";

            let productImage = product.image
                ? `<img src="http://localhost:5001${product.image}" alt="${product.name}">`
                : '<div class="no-image">No Image Available</div>';

            let productDetails = `
                <div class="product-details">
                    <h2>${product.name}</h2>
                    <p><strong>Brand:</strong> ${product.brand}</p>
                    <p><strong>Price:</strong> ₹${product.price}</p>
                    <p><strong>Quantity:</strong> ${product.quantity}</p>
                    <p><strong>Net Weight:</strong> ${product.netWeight}</p>
                    <p><strong>Manufacturer:</strong> ${product.manufacturer}</p>
                    <p><strong>Description:</strong> ${product.description}</p>
                    <p class="price">Total Price: ₹${product.totalPrice}</p>
                    <button class="buy-btn" onclick="placeOrder('${product._id}')">Buy Now</button>
                </div>
            `;

            productCard.innerHTML = `
                <div class="product-image">${productImage}</div>
                ${productDetails}
            `;

            productContainer.appendChild(productCard);
        });
    } else {
        productContainer.innerHTML = "<p>No products found!</p>";
    }
}

// Function to handle search
function searchProducts() {
    let searchInput = document.getElementById("searchInput").value.toLowerCase();
    let filteredProducts = allProducts.filter(product =>
        product.name.toLowerCase().includes(searchInput) ||
        product.brand.toLowerCase().includes(searchInput) ||
        product.description.toLowerCase().includes(searchInput)
    );

    displayProducts(filteredProducts);
}

function placeOrder(productId) {
    // Get product details from allProducts array
    let selectedProduct = allProducts.find(product => product._id === productId);
    
    if (selectedProduct) {
        // Store product details in sessionStorage
        sessionStorage.setItem("selectedProduct", JSON.stringify(selectedProduct));

        // Redirect to user form
        window.location.href = "userForm.html";
    } else {
        alert("Product details not found!");
    }
}


// Load Products on Page Load
document.addEventListener("DOMContentLoaded", function () {
    fetchProducts();
});