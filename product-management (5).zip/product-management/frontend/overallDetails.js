document.addEventListener("DOMContentLoaded", function () {
    const product = JSON.parse(sessionStorage.getItem("selectedProduct"));
    let customer = JSON.parse(sessionStorage.getItem("customerDetails"));

    if (product && customer) {
        // Populate Product Details
        document.getElementById("productImage").src = `http://localhost:5001${product.image}`;
        document.getElementById("productName").textContent = product.name;
        document.getElementById("productBrand").textContent = product.brand;
        document.getElementById("productPrice").textContent = `₹${product.price}`;

        // Populate Customer Details
        updateCustomerDetails();
    } else {
        alert("Missing order details! Please go back and try again.");
    }

    function updateCustomerDetails() {
        document.getElementById("customerName").innerHTML = `${customer.name} <button onclick="editDetail('name')">Edit</button>`;
        document.getElementById("customerLocation").innerHTML = `${customer.location} <button onclick="editDetail('location')">Edit</button>`;
        document.getElementById("customerPhone").innerHTML = `${customer.phone} <button onclick="editDetail('phone')">Edit</button>`;
        document.getElementById("customerEmail").innerHTML = `${customer.email} <button onclick="editDetail('email')">Edit</button>`;
        document.getElementById("customerDeliveryTime").innerHTML = `${new Date(customer.deliveryTime).toLocaleString()} <button onclick="editDetail('deliveryTime')">Edit</button>`;
    }

    // Edit Customer Details
    window.editDetail = function (field) {
        let newValue = prompt(`Enter new ${field}:`, customer[field]);
        if (newValue) {
            customer[field] = newValue;
            sessionStorage.setItem("customerDetails", JSON.stringify(customer));
            updateCustomerDetails(); // Refresh the details
        }
    };

    document.getElementById("confirmOrder").addEventListener("click", function () {
        sessionStorage.setItem("orderConfirmed", "true");
        window.location.href = "payment.html";
    });
});
