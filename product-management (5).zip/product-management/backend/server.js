const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/login.html"));
});

// Serve static files from frontend folder
app.use(express.static(path.join(__dirname, "../frontend")));

// Serve uploaded images

app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

const uploadsPath = path.join(__dirname, "../uploads");
console.log("Serving static files from:", uploadsPath); // Debugging
app.use("/uploads", express.static(uploadsPath));

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/products_db", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

// Routes
app.use("/api/products", require("./routes/productRoutes"));
const PORT = 5001 ;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));