const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  quantity: { type: Number, required: true },
  brand: { type: String, required: true },
  netWeight: { type: String, required: true },
  manufacturer: { type: String, required: true },
  totalPrice: { type: Number, required: true },
  description: { type: String, required: true },
  image: { type: String } // Add image field
}, { timestamps: true });

module.exports = mongoose.model("Product", ProductSchema);