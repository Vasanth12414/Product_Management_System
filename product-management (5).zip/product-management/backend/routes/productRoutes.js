const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const Product = require("../models/Product");

const router = express.Router();

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer Setup for Image Uploads
const storage = multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
        cb(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage });

// Fetch All Products
router.get("/", async (req, res) => {
    try {
        const products = await Product.find();
        res.json({ success: true, products });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error fetching products" });
    }
});

// Upload Product Image
// In the upload route
router.post("/:id/upload", upload.single("image"), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, message: "No image file uploaded" });
        }
  
        const productId = req.params.id;
        const imageUrl = `/uploads/${req.file.filename}`; // Save the relative path
  
        const updatedProduct = await Product.findByIdAndUpdate(
            productId,
            { image: imageUrl }, // Save the image URL in the database
            { new: true }
        );
  
        if (!updatedProduct) {
            return res.status(404).json({ success: false, message: "Product not found" });
        }
  
        res.json({ success: true, message: "Image uploaded!", product: updatedProduct });
    } catch (error) {
        res.status(500).json({ success: false, message: "Failed to upload image" });
    }
  });


  router.delete("/:id", async (req, res) => {
    try {
        const productId = req.params.id;
        console.log("🔹 Deleting product with ID:", productId); // Log the ID

        const deletedProduct = await Product.findByIdAndDelete(productId);

        if (!deletedProduct) {
            console.log("🔹 Product not found:", productId); // Log if product not found
            return res.status(404).json({ success: false, message: "Product not found" });
        }

        console.log("🔹 Product deleted successfully:", deletedProduct); // Log success
        res.json({ success: true, message: "Product deleted successfully" });
    } catch (error) {
        console.error("❌ Error deleting product:", error); // Log errors
        res.status(500).json({ success: false, message: "Failed to delete product" });
    }
});
// Update a Product
router.put("/:id", async (req, res) => {
    try {
        const productId = req.params.id;
        const updatedData = req.body;

        const updatedProduct = await Product.findByIdAndUpdate(productId, updatedData, { new: true });

        if (!updatedProduct) {
            return res.status(404).json({ success: false, message: "Product not found" });
        }

        res.json({ success: true, message: "Product updated successfully", product: updatedProduct });
    } catch (error) {
        res.status(500).json({ success: false, message: "Failed to update product" });
    }
});

  // Add a new product
router.post("/", async (req, res) => {
    try {
        const { name, price, quantity, brand, netWeight, manufacturer, totalPrice, description } = req.body;

        // Validate required fields
        if (!name || !price || !quantity || !brand || !netWeight || !manufacturer || !description) {
            return res.status(400).json({ success: false, message: "All fields are required" });
        }

        // Create a new product
        const newProduct = new Product({
            name,
            price,
            quantity,
            brand,
            netWeight,
            manufacturer,
            totalPrice: (price * quantity).toFixed(2), // Calculate total price
            description,
        });

        // Save the product to the database
        await newProduct.save();

        res.json({ success: true, message: "Product added successfully", product: newProduct });
    } catch (error) {
        console.error("Error adding product:", error);
        res.status(500).json({ success: false, message: "Failed to add product" });
    }
});
module.exports = router;